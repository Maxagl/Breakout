***
If the shortcut for breakout don't work, use the "breakout.exe" in breakout folder
***
ショ—トカットが使えない場合は、breakout フォルダ中の"breakout.exe"を使ってください
***
快捷方式用不了的时候，直接打开breakout文件夹里面的"breakout.exe"